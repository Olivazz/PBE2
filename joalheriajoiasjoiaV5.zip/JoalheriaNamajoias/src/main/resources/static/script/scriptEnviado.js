document.addEventListener("DOMContentLoaded", function () {
    alert("Seu cadastro foi enviado com sucesso!");
});
