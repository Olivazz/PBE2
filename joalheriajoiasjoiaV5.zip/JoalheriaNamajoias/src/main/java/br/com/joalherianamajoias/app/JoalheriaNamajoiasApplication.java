package br.com.joalherianamajoias.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoalheriaNamajoiasApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoalheriaNamajoiasApplication.class, args);
	}

}
